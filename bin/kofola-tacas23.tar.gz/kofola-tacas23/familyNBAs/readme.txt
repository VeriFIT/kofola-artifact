This directory contains the family of NBAs for which existing works construct a DPA of size n! while ours gives a DELA/DPA of size 2^n.
