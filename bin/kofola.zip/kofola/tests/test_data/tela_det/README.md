# Benchmarks from determinisation of TELA automata

Automata were obtained from [figshare](https://figshare.com/articles/software/Determinization_and_Limit-determinization_of_Emerson-Lei_Automata_-_Supplementary_material_ATVA_21_/14838654/2?file=28654152) where they are stored as a suplementary material for the paper

* Tobias John, Simon Jantsch, Christel Baier, Sascha Klüppelholz (2021). Determinization and Limit-determinization of Emerson-Lei Automata, In proceedings of ATVA'21. LNCS vol 12971. Springer.

The supplementary materials are distributed under CC BY 4.0.