// Copyright (C) 2022  The Kofola Authors
//
// Kofola is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Kofola is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// kofola
#include "complement_tela.hpp"
#include "../util/util.hpp"
#include "decomposer.hpp"

// Spot
#include <spot/twaalgos/postproc.hh>
#include <spot/twaalgos/product.hh>
#include <spot/twaalgos/complete.hh>
#include <spot/twaalgos/isdet.hh>
#include <spot/twaalgos/complement.hh>

// standard library
#include <queue>

spot::twa_graph_ptr kofola::complement_deterministic(const spot::twa_graph_ptr& aut)
{
	// Make the automaton complete
	auto complete_aut = spot::complete(aut);
	complete_aut->set_acceptance(complete_aut->get_acceptance().complement());

	// Apply postprocessing using the shared function
	return apply_postprocessing(complete_aut, aut);
}

spot::twa_graph_ptr kofola::apply_postprocessing(const spot::twa_graph_ptr& aut, const spot::twa_graph_ptr& original_aut)
{
	spot::twa_graph_ptr result = aut;
	
	// postprocessing  TODO: should also consider other options
	if (!kofola::has_value("raw", "yes", kofola::OPTIONS.params)) {
		spot::postprocessor p_post;
		if ("buchi" == kofola::OPTIONS.output_type) {
			p_post.set_type(spot::postprocessor::Buchi);
		}
        else if("tgba" == kofola::OPTIONS.output_type) {
            p_post.set_type(spot::postprocessor::GeneralizedBuchi);
        } else {
			p_post.set_type(spot::postprocessor::Generic);
		}

		// for automata with many APs the reduction timeoutes
		if(is_post_reduction_suitable(original_aut)) {
			if(result->num_states() < 2000) {
				p_post.set_type(spot::postprocessor::GeneralizedBuchi);
			} 
			p_post.set_level(spot::postprocessor::Low);
			
			result = p_post.run(result);
		}
	}

	return result;
}

spot::twa_graph_ptr kofola::complement_tela(const spot::twa_graph_ptr& aut)
{
	spot::twa_graph_ptr aut_reduced;
	std::vector<bdd> implications;
	spot::twa_graph_ptr aut_tmp = nullptr;
	if (aut_tmp)
		aut_reduced = aut_tmp;
	else
		aut_reduced = aut;

	// Special case: if the automaton is deterministic, complement by
	// making it complete and complementing the acceptance condition
	if (spot::is_deterministic(aut_reduced)) {
		return complement_deterministic(aut_reduced);
	}

	spot::scc_info scc(aut_reduced, spot::scc_info_options::ALL);

	if (kofola::has_value("postponed", "yes", kofola::OPTIONS.params)) { // postponed procedure
		// saturation
		if (kofola::has_value("saturate", "yes", kofola::OPTIONS.params)) {
			aut_reduced = kofola::saturate(aut_reduced, scc);
			spot::scc_info scc_sat(aut_reduced, spot::scc_info_options::ALL);
			scc = scc_sat;
		}

		// decompose source automaton - TODO: this should be done properly
		helpers::decomposer decomp(aut_reduced);
		auto decomposed = decomp.run(
			true,
			kofola::has_value("merge_iwa", "yes", kofola::OPTIONS.params),
			kofola::has_value("merge_det", "yes", kofola::OPTIONS.params));

		if (decomposed.size() > 0) {
			std::vector<spot::twa_graph_ptr> part_res;

			spot::postprocessor p_pre;
			p_pre.set_type(spot::postprocessor::Buchi);
			p_pre.set_level(spot::postprocessor::High);

			spot::postprocessor p_post;
			p_post.set_type(spot::postprocessor::Generic);
			if (kofola::has_value("low_red_interm", "yes", kofola::OPTIONS.params)) {
				p_post.set_level(spot::postprocessor::Low);
			} else {
				p_post.set_level(spot::postprocessor::High);
			}

			// comparison for priority queue - smallest automata should be at top
			auto aut_cmp = [](const auto& lhs, const auto& rhs){ return lhs->num_states() > rhs->num_states();};
			std::priority_queue<spot::twa_graph_ptr,
				std::vector<spot::twa_graph_ptr>, decltype(aut_cmp)> aut_queue(aut_cmp);
			for (auto aut : decomposed)
			{
				// if (decomp_options.scc_compl_high)
				//   p.set_level(spot::postprocessor::High);
				// else
				//   p.set_level(spot::postprocessor::Low);
				// complement each automaton
				auto aut_preprocessed = p_pre.run(aut);
				spot::scc_info part_scc(aut_preprocessed, spot::scc_info_options::ALL);

				auto res = kofola::complement_sync(aut_preprocessed);
				// postprocessing for each automaton
				// part_res.push_back(p_post.run(dec_aut));
				aut_queue.push(p_post.run(res));
			}

			assert(!aut_queue.empty());
			while (aut_queue.size() > 1) { // until single aut remains
				auto first_aut = aut_queue.top();
				aut_queue.pop();
				DEBUG_PRINT_LN("first_aut size = " + std::to_string(first_aut->num_states()));
				auto second_aut = aut_queue.top();
				aut_queue.pop();
				DEBUG_PRINT_LN("second_aut size = " + std::to_string(second_aut->num_states()));
				auto result = spot::product(first_aut, second_aut);
				result = p_post.run(result);
				aut_queue.push(result);
			}

			return aut_queue.top();
		} else {
			assert(false);
		}
	}

	// if tela=yes, we use Generic preprocessor, 
	// otherwise we use Buchi preprocessor (the input is a TBA)
	spot::postprocessor p;
	if (kofola::has_value("tela", "yes", kofola::OPTIONS.params)) {
		p.set_type(spot::postprocessor::Generic);
	} else {
		p.set_type(spot::postprocessor::Buchi);
	}
	if (is_reduction_suitable(aut_reduced)) {
		p.set_level(spot::postprocessor::High);
	} else {
		p.set_level(spot::postprocessor::Low);
	}
		
	spot::twa_graph_ptr aut_to_compl;
	aut_to_compl = p.run(aut_reduced);

	auto res = kofola::complement_sync(aut_to_compl);
	DEBUG_PRINT_LN("finished call to run_new()");

	return apply_postprocessing(res, aut_reduced);
}

bool kofola::is_reduction_suitable(const spot::twa_graph_ptr& aut) {
	// The automaton is not suitable if:
	// 1. The number of APs is bigger than 10
	// 2. The automaton is deterministic
	
	// Get the number of atomic propositions from the dictionary
	unsigned num_aps = aut->get_dict()->var_map.size();
	
	// Check if number of APs is too large
	if (num_aps > 5) {
		return false;
	}
	
	// Check if the automaton is deterministic
	if (spot::is_deterministic(aut)) {
		return false;
	}
	
	return true;
}

bool kofola::is_post_reduction_suitable(const spot::twa_graph_ptr& aut) {
	// Get the number of atomic propositions from the dictionary
	unsigned num_aps = aut->get_dict()->var_map.size();
	
	// Check if number of APs is too large
	if (num_aps > 10) {
		return false;
	}
	return true;
}
